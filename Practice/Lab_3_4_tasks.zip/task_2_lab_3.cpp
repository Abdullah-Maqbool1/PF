#include <iostream>
#include <fstream>
using namespace std;

int main() {

	int number, count=0;
	double ave = 0, sum= 0;

	ifstream fin;
	fin.open("task_2_input.txt");
	while (fin>>number)
	{
		sum += number;
		count++;
	}

	fin.close();

	ave = sum / count;
	cout << "Sum is: " << sum << endl;
	cout << "Average is: " << ave << endl;
	
	ofstream fout;
	fout.open("task_2_output.txt");
	fout << "Sum is: " << sum<<endl;
	fout << "Average is: " << ave << endl;
	fout.close();
	return 0;
}