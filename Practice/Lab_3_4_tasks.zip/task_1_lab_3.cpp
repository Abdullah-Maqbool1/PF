#include <iostream>
#include <fstream>
using namespace std;

int main() {
	char name[50];
	ifstream fin;
	fin.open("task_1_input.txt");

	ofstream fout;
	fout.open("task_1_output.txt");
	while (!fin.eof())
	{
		fin >> name;
		cout << name << endl;
		fout << name<<" ";
	}
	fin.close();
	fout.close();


}	