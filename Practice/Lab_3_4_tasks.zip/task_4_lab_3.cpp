#include <iostream>
#include <fstream>
#include <cstring>

using namespace std;

int main()
{
    char filename[50], ext[7], words[200];
    cout << "Enter file name(without extansion): ";
    cin.getline(filename, 50);

    cout << "Enter Extension(e.g .txt, .bin): ";
    cin.getline(ext, 7);
    cout << "Enter the words: " << endl;
    cin.getline(words, 200);

    ofstream fout;
    fout.open(strcat(filename, ext));
    fout << words;
    fout.close();

    // Read Data from file

    char words2[40];
    ifstream fin;
    fin.open(filename);
    fout.open("task_4_output.txt");
    int word_count = 0;
    while (fin >> words2)
    {
        int index = 0;
        char words3[40] = "\0";

        bool alpha_found = false;

        for (int i = 0; words2[i] != '\0'; i++)
        {
            if ((words2[i] >= 'a' && words2[i] <= 'z') || (words2[i] >= 'A' && words2[i] <= 'Z'))
            {
                words3[index] = words2[i];
                index++;
                alpha_found = true;
            }
        }
        if (alpha_found == true)
        {
            cout << words3 << " ";
            fout << words3 << " ";
            word_count++;
        }
    }

    cout<<"\nTotal words are: "<<word_count;
    fin.close();
    fout.close();

    return 0;
}