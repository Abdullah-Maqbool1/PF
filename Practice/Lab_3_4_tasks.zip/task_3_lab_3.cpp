#include <iostream>
#include <fstream>
using namespace std;

int main() {
	char name[50], grade = '\0';
	double mark1 = 0, mark2 = 0, mark3 = 0, total_marks=0;
	double percent = 0;

	ifstream fin;
	fin.open("task_3_input.txt");
	ofstream fout;
	fout.open("task_3_output.txt");

	while (!fin.eof())
	{
		fin.getline(name, 50, ' ');
		fin >> mark1;
		fin >> mark2;
		fin >> mark3;
		
		total_marks = mark1 + mark2 + mark3;
		percent = (total_marks / 300) * 100;


		if (percent>=0 && percent <= 49.5)
		{
			grade = 'F';
		}
		else if (percent > 49.5  && percent <= 57.5)
		{
			grade = 'D';
		}
		else if (percent > 57.5 && percent <= 71.5)
		{
			grade = 'C';
		}
		else if (percent > 71.5 && percent < 84.5)
		{
			grade = 'B';
		}
		else if (percent >= 84.5)
		{
			grade = 'A';
		}

		cout << name << " Obtained " << grade << " grade";
		fout<< name << " Obtained " << grade << " grade";

	}
	fin.close();
	fout.close();

	return 0;
}