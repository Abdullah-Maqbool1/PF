#include <iostream>
#include <fstream>

using namespace std;
int** readMatrixFromFile(const string& filename, int& rows, int*& cols) {
    ifstream file(filename);
    rows = 0;
    string line;
    file.clear();
    file.seekg(0, ios::beg);
    cols = new int[rows];
    int** matrix = new int* [rows];
    for (int i = 0; i < rows; ++i) {
        int count = 0;
        int num;
        matrix[i] = new int[100]; 
        while (file >> num && num != -99) {
            matrix[i][count++] = num;
        }
        cols[i] = count;
    }

    file.close();
    return matrix;
}

// Function to print the matrix in reverse order
void printMatrixReverse(int** matrix, int rows, int* cols) {
    for (int i = 0; i < rows; ++i) {
        for (int j = cols[i] - 1; j >= 0; --j) {
            cout << matrix[i][j] << " ";
        }
        cout << endl;
    }
}

// Function to free dynamically allocated memory
void freeMatrix(int** matrix, int rows) {
    for (int i = 0; i < rows; ++i) {
        delete[] matrix[i];
    }
    delete[] matrix;
}

int main() {
    int rows;
    int* cols;

    int** matrix = readMatrixFromFile("Data.txt", rows, cols);

    if (matrix != nullptr) {
        cout << "Original Matrix (Reversed):" << endl;
        printMatrixReverse(matrix, rows, cols);
        freeMatrix(matrix, rows);
        delete[] cols;
    }

    return 0;
}
