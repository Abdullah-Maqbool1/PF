#include <iostream>
#include <fstream>

using namespace std;

int** readDataFromFile(const string& filename, int& rows, int*& cols) {
    ifstream file(filename);
    if (!file) {
        cerr << "Error opening file " << filename << endl;
        return nullptr;
    }
    rows = 0;
    int maxCols = 0;
    string line;
    while (file.get()) {
        ++rows;
        int count = 0;
       
        int num;
        if (count > maxCols) {
            maxCols = count;
        }
    }
    file.clear();
    file.seekg(0, ios::beg);

    cols = new int[rows];
    int** data = new int* [rows];

    // Read the data
    for (int i = 0; i < rows; ++i) {
        data[i] = new int[maxCols];
        int count = 0;
        string num;
        cols[i] = count;
    }

    file.close();
    return data;
}

// Function to print the original data
void printData(int** data, int rows, int* cols) {
    cout << "Original Data:" << endl;
    cout << "?";
    for (int i = 0; i < rows; ++i) {
        cout << "(";
        for (int j = 0; j < cols[i]; ++j) {
            cout << data[i][j];
            if (j < cols[i] - 1) {
                cout << "&";
            }
        }
        cout << ")";
        if (i < rows - 1) {
            cout << "@";
        }
    }
    cout << endl;
}

void removeValue(int** data, int rows, int* cols, int row, int col) {
    
    --col;

    if (row >= 0 && row < rows && col >= 0 && col < cols[row]) {
        
        for (int i = col; i < cols[row] - 1; ++i) {
            data[row][i] = data[row][i + 1];
        }
        
        --cols[row];
    }
    else {
        cout << "Invalid position specified." << endl;
    }
}


void printUpdatedData(int** data, int rows, int* cols) {
    cout << "Updated Data:" << endl;
    cout << "?";
    for (int i = 0; i < rows; ++i) {
        cout << "(";
        for (int j = 0; j < cols[i]; ++j) {
            cout << data[i][j];
            if (j < cols[i] - 1) {
                cout << "&";
            }
        }
        cout << ")";
        if (i < rows - 1) {
            cout << "@";
        }
    }
    cout << endl;
}

// Function to free dynamically allocated memory
void freeData(int** data, int rows) {
    for (int i = 0; i < rows; ++i) {
        delete[] data[i];
    }
    delete[] data;
}

int main() {
    int rows;
    int* cols;

    int** data = readDataFromFile("Data.txt", rows, cols);

    if (data != nullptr) {
        printData(data, rows, cols);

        int row, col;
        cout << "Enter the position (row, col) to remove (1-based index): ";
        cin >> row >> col;

        removeValue(data, rows, cols, row, col);
        printUpdatedData(data, rows, cols);

        freeData(data, rows);
        delete[] cols;
    }

    return 0;
}
