#include <iostream>
#include <fstream>
using namespace std;
int** readMatrixFromFile(const string& filename, int& rows, int*& cols) {
    ifstream file(filename);
    file >> rows;
    cols = new int[rows];
    int** matrix = new int* [rows];
    for (int i = 0; i < rows; ++i) {
        file >> cols[i];
        matrix[i] = new int[cols[i]];
        for (int j = 0; j < cols[i]; ++j) {
            file >> matrix[i][j];
        }
    }
    file.close();
    return matrix;
}

// Function to print a matrix
void printMatrix(int** matrix, int rows, int* cols) {
    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < cols[i]; ++j) {
            cout << matrix[i][j] << " ";
        }
        cout << endl;
    }
}

// Function to add two matrices
int** addMatrices(int** matrix1, int** matrix2, int rows, int* cols) {
    int** sumMatrix = new int* [rows];
    for (int i = 0; i < rows; ++i) {
        sumMatrix[i] = new int[cols[i]];
        for (int j = 0; j < cols[i]; ++j) {
            sumMatrix[i][j] = matrix1[i][j] + matrix2[i][j];
        }
    }
    return sumMatrix;
}

// Function to free dynamically allocated memory
void freeMatrix(int** matrix, int rows) {
    for (int i = 0; i < rows; ++i) {
        delete[] matrix[i];
    }
    delete[] matrix;
}

int main() {
    int rows1, rows2;
    int* cols1, * cols2;

    int** matrix1 = readMatrixFromFile("Matrix1.txt", rows1, cols1);
    int** matrix2 = readMatrixFromFile("Matrix2.txt", rows2, cols2);

    if (rows1 != rows2) {
        cerr << "Matrices must have the same number of rows!" << endl;
        return 1;
    }

    for (int i = 0; i < rows1; ++i) {
        if (cols1[i] != cols2[i]) {
            cerr << "Matrices must have the same number of columns in each row!" << endl;
            return 1;
        }
    }

    int** sumMatrix = addMatrices(matrix1, matrix2, rows1, cols1);

    cout << "Matrix 1:" << endl;
    printMatrix(matrix1, rows1, cols1);

    cout << "Matrix 2:" << endl;
    printMatrix(matrix2, rows1, cols2);

    cout << "Sum Matrix:" << endl;
    printMatrix(sumMatrix, rows1, cols1);

    freeMatrix(matrix1, rows1);
    freeMatrix(matrix2, rows1);
    freeMatrix(sumMatrix, rows1);
    delete[] cols1;
    delete[] cols2;

    return 0;
}
