#include <iostream>
#include <fstream>

using namespace std;
int countVowels(const string& str) {
    int count = 0;
    for (char c : str) {
        if (tolower(c) == 'a' || tolower(c) == 'e' || tolower(c) == 'i' || tolower(c) == 'o' || tolower(c) == 'u') {
            ++count;
        }
    }
    return count;
}
string removeVowels(const string& str) {
    string result;
    for (char c : str) {
        if (tolower(c) != 'a' && tolower(c) != 'e' && tolower(c) != 'i' && tolower(c) != 'o' && tolower(c) != 'u') {
            result += c;
        }
    }
    return result;
}
void readDataFromFile(const string& filename, string**& ids, string**& names, int& numStudents) {
    ifstream file(filename);
    if (!file) {
        cerr << "Error opening file " << filename << endl;
        return;
    }

    // Count number of students
    numStudents = 0;
    string line;
    while (file.get()) {
        ++numStudents;
    }
    file.clear();
    file.seekg(0, ios::beg);
    ids = new string * [numStudents];
    names = new string * [numStudents];
    for (int i = 0; i < numStudents; ++i) {
        ids[i] = new string[1]; 
        names[i] = new string[1]; 
        file >> ids[i][0] >> names[i][0];
        names[i][0] = removeVowels(names[i][0]);
    }

    file.close();
}
void displayDataWithoutVowels(string** ids, string** names, int numStudents) {
    cout << "Output on Console:" << endl;
    for (int i = 0; i < numStudents; ++i) {
        cout << ids[i][0] << " " << names[i][0] << endl;
    }
}


void freeData(string** ids, string** names, int numStudents) {
    for (int i = 0; i < numStudents; ++i) {
        delete[] ids[i];
        delete[] names[i];
    }
    delete[] ids;
    delete[] names;
}

int main() {
    string** ids = nullptr;
    string** names = nullptr;
    int numStudents = 0;

    readDataFromFile("Data 11.txt", ids, names, numStudents);
    displayDataWithoutVowels(ids, names, numStudents);
    freeData(ids, names, numStudents);

    return 0;
}
