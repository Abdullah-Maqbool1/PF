#include <iostream>
#include <fstream>

using namespace std;
int countVowels(const string& str) {
    int count = 0;
    for (char c : str) {
        if (tolower(c) == 'a' || tolower(c) == 'e' || tolower(c) == 'i' || tolower(c) == 'o' || tolower(c) == 'u') {
            ++count;
        }
    }
    return count;
}
string removeVowels(const string& str) {
    string result;
    for (char c : str) {
        if (tolower(c) != 'a' && tolower(c) != 'e' && tolower(c) != 'i' && tolower(c) != 'o' && tolower(c) != 'u') {
            result += c;
        }
    }
    return result;
}


void readDataFromFile(const string& filename, string**& ids, string**& names, int& numStudents) {
    ifstream file(filename);
    if (!file) {
        cerr << "Error opening file " << filename << endl;
        return;
    }

    // Count number of students
    numStudents = 0;
    string line;
    file.clear();
    file.seekg(0, ios::beg);

   
    ids = new string * [numStudents];
    names = new string * [numStudents];

    
    for (int i = 0; i < numStudents; ++i) {
        ids[i] = new string[1]; 
        names[i] = new string[1]; 
        file >> ids[i][0] >> names[i][0];
        
        names[i][0] = removeVowels(names[i][0]);
    }

    file.close();
}


void displayDataWithoutVowels(string** ids, string** names, int numStudents) {
    cout << "Output on Console:" << endl;
    for (int i = 0; i < numStudents; ++i) {
        cout << ids[i][0] << " " << names[i][0] << endl;
    }
}
void insertValue(string** ids, string** names, int& numStudents, int row, int col, const string& id, const string& name) {
    
    --row;
    --col;

    if (row >= 0 && row < numStudents) {
        
        for (int i = numStudents; i > row; --i) {
            ids[i] = ids[i - 1];
            names[i] = names[i - 1];
        }
       
        ids[row] = new string[1];
        names[row] = new string[1];
        ids[row][0] = id;
        names[row][0] = removeVowels(name);
        ++numStudents;
    }
    else {
        cout << "Invalid position specified for insertion." << endl;
    }
}


void removeValue(string** ids, string** names, int& numStudents, int row, int col) {
    
    --row;
    --col;

    if (row >= 0 && row < numStudents && col >= 0 && col < 1) {
      
        delete[] ids[row];
        delete[] names[row];
        for (int i = row; i < numStudents - 1; ++i) {
            ids[i] = ids[i + 1];
            names[i] = names[i + 1];
        }
        --numStudents;
    }
    else {
        cout << "Invalid position specified for removal." << endl;
    }
}
void freeData(string** ids, string** names, int numStudents) {
    for (int i = 0; i < numStudents; ++i) {
        delete[] ids[i];
        delete[] names[i];
    }
    delete[] ids;
    delete[] names;
}

int main() {
    string** ids = nullptr;
    string** names = nullptr;
    int numStudents = 0;

    readDataFromFile("Data.txt", ids, names, numStudents);
    displayDataWithoutVowels(ids, names, numStudents);
    insertValue(ids, names, numStudents, 2, 3, "89", "NewStudent");
    removeValue(ids, names, numStudents, 3, 2);
    cout << "Updated Data:" << endl;
    displayDataWithoutVowels(ids, names, numStudents);

    // Clean up
    freeData(ids, names, numStudents);

    return 0;
}
