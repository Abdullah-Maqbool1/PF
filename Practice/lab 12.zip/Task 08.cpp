#include <iostream>
#include <fstream>

using namespace std;
double** readDataFromFile(const string& filename, int& rows, int*& cols) {
    ifstream file(filename);
    rows = 0;
    string line;
    while (file.get()) {
        ++rows;
    }
    file.clear();
    file.seekg(0, ios::beg);
    cols = new int[rows];
    double** data = new double* [rows];
    for (int i = 0; i < rows; ++i) {
        data[i] = nullptr;
        string num;
        int count = 0;
        while (file >> num) {
            if (data[i] == nullptr) {
                data[i] = new double[100];  
            }
            char next_char = file.peek();
            if (next_char == '\n' || next_char == EOF) break;
        }
        cols[i] = count;
    }

    file.close();
    return data;
}
void sumRowWise(double** data, int rows, int* cols) {
    cout << "Sum row-wise: ";
    for (int i = 0; i < rows; ++i) {
        double sum = 0.0;
        for (int j = 0; j < cols[i]; ++j) {
            sum += data[i][j];
        }
        if (i < rows - 1) {
            cout << sum << ", ";
        }
        else {
            cout << sum << endl;
        }
    }
}

// Function to calculate and print the sum column-wise
void sumColumnWise(double** data, int rows, int* cols) {
    int maxCols = 0;
    for (int i = 0; i < rows; ++i) {
        if (cols[i] > maxCols) {
            maxCols = cols[i];
        }
    }

    cout << "Sum column-wise: ";
    for (int j = 0; j < maxCols; ++j) {
        double sum = 0.0;
        for (int i = 0; i < rows; ++i) {
            if (j < cols[i]) {
                sum += data[i][j];
            }
        }
        if (j < maxCols - 1) {
            cout << sum << ", ";
        }
        else {
            cout << sum << endl;
        }
    }
}
void freeData(double** data, int rows) {
    for (int i = 0; i < rows; ++i) {
        delete[] data[i];
    }
    delete[] data;
}

int main() {
    int rows;
    int* cols;

    double** data = readDataFromFile("Data 08.txt", rows, cols);

    if (data != nullptr) {
        sumRowWise(data, rows, cols);
        sumColumnWise(data, rows, cols);

        freeData(data, rows);
        delete[] cols;
    }

    return 0;
}
