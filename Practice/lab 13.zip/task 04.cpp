#include <iostream>
#include <fstream>
using namespace std;
int** readMatrixFromFile(const string& filename, int& rows, int& cols) {
    ifstream file(filename);
    rows = 0;
    cols = 0;
    string line;
    while (file.get()) {
        ++rows;
        if (rows == 1) {
            for (char ch : line) {
                if (ch == ' ') {
                    ++cols;
                }
            }
           
        }
    }
    file.clear();
    file.seekg(0, ios::beg);

    // Allocate jagged array
    int** matrix = new int* [rows];
    for (int i = 0; i < rows; ++i) {
        matrix[i] = new int[cols];
        for (int j = 0; j < cols; ++j) {
            file >> matrix[i][j];
        }
    }

    file.close();
    return matrix;
}

// Function to print the matrix column-wise
void printMatrixColumnWise(int** matrix, int rows, int cols) {
    for (int j = 0; j < cols; ++j) {
        for (int i = 0; i < rows; ++i) {
            cout << matrix[i][j] << " ";
        }
        cout << endl;
    }
}
void freeMatrix(int** matrix, int rows) {
    for (int i = 0; i < rows; ++i) {
        delete[] matrix[i];
    }
    delete[] matrix;
}

int main() {
    int rows, cols;

    int** matrix = readMatrixFromFile("Data 04.txt", rows, cols);

    if (matrix != nullptr) {
        cout << "Matrix Column-wise:" << endl;
        printMatrixColumnWise(matrix, rows, cols);
        freeMatrix(matrix, rows);
    }

    return 0;
}
