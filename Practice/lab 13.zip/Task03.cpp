#include <iostream>
#include <fstream>

using namespace std;
int** readMatrixFromFile(const string& filename, int& size) {
    ifstream file(filename);
    if (!file) {
        cerr << "Error opening file " << filename << endl;
        return nullptr;
    }
    size = 0;
    string line;
    file.clear();
    file.seekg(0, ios::beg);
    int** matrix = new int* [size];
    for (int i = 0; i < size; ++i) {
        matrix[i] = new int[size];
        for (int j = 0; j < size; ++j) {
            file >> matrix[i][j];
        }
    }

    file.close();
    return matrix;
}
void printDiagonal(int** matrix, int size) {
    for (int i = 0; i < size; ++i) {
        cout << matrix[i][i] << " ";
    }
    cout << endl;
}
void freeMatrix(int** matrix, int size) {
    for (int i = 0; i < size; ++i) {
        delete[] matrix[i];
    }
    delete[] matrix;
}

int main() {
    int size;

    int** matrix = readMatrixFromFile("Data 03.txt", size);

    if (matrix != nullptr) {
        cout << "Diagonal of the Matrix:" << endl;
        printDiagonal(matrix, size);
        freeMatrix(matrix, size);
    }

    return 0;
}
