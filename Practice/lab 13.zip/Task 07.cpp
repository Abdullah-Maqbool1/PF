#include <iostream>
#include <fstream>

using namespace std;
string* readNamesFromFile(const string& filename, int& rows) {
    ifstream file(filename);
    if (!file) {
        cerr << "Error opening file " << filename << endl;
        return nullptr;
    }
    rows = 0;
    string line;
    while (file.get()) {
        ++rows;
    }
    file.clear();
    file.seekg(0, ios::beg);

    string* names = new string[rows];

    file.close();
    return names;
}

string* mergeNames(string* firstNames, string* lastNames, int rows) {
    string* fullNames = new string[rows];

    for (int i = 0; i < rows; ++i) {
        fullNames[i] = firstNames[i] + " " + lastNames[i];
    }

    return fullNames;
}
void writeFullNamesToFile(const string& filename, string* fullNames, int rows) {
    ofstream file(filename);
    if (!file) {
        cerr << "Error opening file " << filename << " for writing." << endl;
        return;
    }

    for (int i = 0; i < rows; ++i) {
        file << fullNames[i] << endl;
    }

    file.close();
}
void freeNames(string* names) {
    delete[] names;
}

int main() {
    int rows;
    string* firstNames = readNamesFromFile("fname.txt", rows);
    string* lastNames = readNamesFromFile("lname.txt", rows);

    if (firstNames != nullptr && lastNames != nullptr) {
        string* fullNames = mergeNames(firstNames, lastNames, rows);

        cout << "Merged Full Names:" << endl;
        for (int i = 0; i < rows; ++i) {
            cout << fullNames[i] << endl;
        }

        writeFullNamesToFile("fullnames.txt", fullNames, rows);

        freeNames(firstNames);
        freeNames(lastNames);
        freeNames(fullNames);
    }

    return 0;
}
