#include <iostream>
#include <fstream>

using namespace std;

// Function to read quiz marks from a file
float** readMarksFromFile(const string& filename, int& rows, int*& cols) {
    ifstream file(filename);
    rows = 0;
    string line;
    while (file.get()) {
        ++rows;
    }
    file.clear();
    file.seekg(0, ios::beg);
    cols = new int[rows];
    float** marks = new float* [rows];
    for (int i = 0; i < rows; ++i) {
        int count = 0;
        float num;
        marks[i] = new float[100];  
        while (file >> num && num != -99) {
            marks[i][count++] = num;
        }
        cols[i] = count;
    }

    file.close();
    return marks;
}

// Function to print the highest marks for each student
void printHighestMarks(float** marks, int rows, int* cols) {
    for (int i = 0; i < rows; ++i) {
        float highest = marks[i][0];
        for (int j = 1; j < cols[i]; ++j) {
            if (marks[i][j] > highest) {
                highest = marks[i][j];
            }
        }
        cout << "Highest marks for student " << i + 1 << " are: " << highest << endl;
    }
}

// Function to free dynamically allocated memory
void freeMarks(float** marks, int rows) {
    for (int i = 0; i < rows; ++i) {
        delete[] marks[i];
    }
    delete[] marks;
}

int main() {
    int rows;
    int* cols;

    float** marks = readMarksFromFile("Data 05.txt", rows, cols);

    if (marks != nullptr) {
        printHighestMarks(marks, rows, cols);
        freeMarks(marks, rows);
        delete[] cols;
    }

    return 0;
}
