#include <iostream>
#include <fstream>

using namespace std;

// Function to read data from a file into a jagged array
int** readDataFromFile(const string& filename, int& rows, int*& cols) {
    ifstream file(filename);
    if (!file) {
        cerr << "Error opening file " << filename << endl;
        return nullptr;
    }

    // Determine the number of rows and maximum columns
    rows = 0;
    int maxCols = 0;
    string line;
    while (file.get()) {
        ++rows;
        int count = 0;
        int num;
        if (count > maxCols) {
            maxCols = count;
        }
    }
    file.clear();
    file.seekg(0, ios::beg);

    // Allocate columns array and jagged array
    cols = new int[rows];
    int** data = new int* [rows];

    // Read the data
    for (int i = 0; i < rows; ++i) {
        data[i] = new int[maxCols];
        int count = 0;
        string num;
        cols[i] = count;
    }

    file.close();
    return data;
}

// Function to sort each row in ascending order
void sortRows(int** data, int rows, int* cols) {
    for (int i = 0; i < rows; ++i) {
        // Bubble sort (ascending)
        for (int j = 0; j < cols[i] - 1; ++j) {
            for (int k = 0; k < cols[i] - j - 1; ++k) {
                if (data[i][k] > data[i][k + 1]) {
                    // Swap
                    int temp = data[i][k];
                    data[i][k] = data[i][k + 1];
                    data[i][k + 1] = temp;
                }
            }
        }
    }
}

// Function to print the sorted data
void printSortedData(int** data, int rows, int* cols) {
    cout << "Updated Data:" << endl;
    cout << "?";
    for (int i = 0; i < rows; ++i) {
        cout << "(";
        for (int j = 0; j < cols[i]; ++j) {
            cout << data[i][j];
            if (j < cols[i] - 1) {
                cout << "&";
            }
        }
        cout << ")";
        if (i < rows - 1) {
            cout << "@";
        }
    }
    cout << endl;
}

// Function to free dynamically allocated memory
void freeData(int** data, int rows) {
    for (int i = 0; i < rows; ++i) {
        delete[] data[i];
    }
    delete[] data;
}

int main() {
    int rows;
    int* cols;

    int** data = readDataFromFile("Data 09.txt", rows, cols);

    if (data != nullptr) {
        cout << "Original Data:" << endl;
        cout << "?";
        for (int i = 0; i < rows; ++i) {
            cout << "(";
            for (int j = 0; j < cols[i]; ++j) {
                cout << data[i][j];
                if (j < cols[i] - 1) {
                    cout << "&";
                }
            }
            cout << ")";
            if (i < rows - 1) {
                cout << "@";
            }
        }
        cout << endl;

        sortRows(data, rows, cols);
        printSortedData(data, rows, cols);

        freeData(data, rows);
        delete[] cols;
    }

    return 0;
}
