#include <iostream>
#include <fstream>

using namespace std;
string* readNamesFromFile(const string& filename, int& rows) {
    ifstream file(filename);
    rows = 0;
    string line;
    while (file.get()) {
        ++rows;
    }
    file.clear();
    file.seekg(0, ios::beg);
    string* names = new string[rows];

    file.close();
    return names;
}
void swapRows(string* names, int row1, int row2) {
    string temp = names[row1];
    names[row1] = names[row2];
    names[row2] = temp;
}
void printNames(string* names, int rows) {
    for (int i = 0; i < rows; ++i) {
        cout << names[i] << endl;
    }
}

void freeNames(string* names) {
    delete[] names;
}

int main() {
    int rows;
    string* names = readNamesFromFile("Data 06.txt", rows);

    if (names != nullptr) {
        cout << "List of Names:" << endl;
        printNames(names, rows);

        int select1, select2;
        cout << "Enter the row numbers (1-based index) to swap: ";
        cin >> select1 >> select2;
        --select1;
        --select2;

        if (select1 >= 0 && select1 < rows && select2 >= 0 && select2 < rows) {
            swapRows(names, select1, select2);

            cout << "Selected " << select1 + 1 << " and " << select2 + 1 << " rows:" << endl;
            printNames(names, rows);
        }
        else {
            cout << "Invalid row numbers selected." << endl;
        }

        freeNames(names);
    }

    return 0;
}
