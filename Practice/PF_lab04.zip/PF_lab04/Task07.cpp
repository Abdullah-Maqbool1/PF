// Printing prime numbers: 
#include<iostream>
using namespace std;

//Creating function: 
void prime_numbers_between(int lower_num, int upper_num) {
    // Checking if the input is correct:
    if ((lower_num > upper_num) || (lower_num < 0)) {
        cout << "Incorrect input!";
    }
    else {
        cout << "Prime numbers between " << lower_num << " and " << upper_num << " are: " << endl;
        for (int i = lower_num;i < upper_num;i++) {
            bool is_prime = true;
            for (int j = lower_num;j * j <= i;j++) {
                if (i % j == 0) {
                    is_prime = false;
                    break;
                }
            }

            if (is_prime) {
                cout << i << " ";
            }
        }
    }
}

int main() {
    int lower_num, upper_num;
    //  Taking input: 
    cout << "Enter two numbers to find prime numbers between them: " << endl;
    cout << "Enter lower num: " << endl;
    cin >> lower_num;
    cout << "Enter upper num: " << endl;
    cin >> upper_num;
    cout << endl;
    // Printing prime numbers: 
    prime_numbers_between(lower_num, upper_num);
    return 0;
}