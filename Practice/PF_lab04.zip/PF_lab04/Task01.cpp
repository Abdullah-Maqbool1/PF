//Display msg: 
#include<iostream>
using namespace std;

void message(char user_message[50]) {
	// Printing message:
	cout << "message: " << user_message << endl;
}

int main() {
	// Taking input:
	char user_message[50];
	cout << "Enter a message: " << endl;
	cin.getline(user_message,100);
	message(user_message);
	return 0;
}