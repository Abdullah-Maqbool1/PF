// Calculate maximum value:
#include<iostream>
using namespace std;

int max(int a, int b) {
	int max_num{};
	if (a > b)
		max_num = a;

	else if (a < b)
		max_num = b;
	return max_num;
}

int main() {
	int x, y;
	// Taking Input:
	cout << "Enter x: " << endl;
	cin >> x;
	cout << "Enter y: " << endl;
	cin >> y;
	// Printing maximum value:
	if (x != y) {
		cout << "Maximum value between " << x << " and " << y << " is: " << max(x, y) << endl;
	}
	// If in case, both x and y are equal:
	else {
		cout << "Both are equal!" << endl;
	}
	return 0;
}