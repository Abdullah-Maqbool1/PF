//Caculate total,average and percentage: 
#include<iostream>
using namespace std;

int data(int marks1,int marks2,int marks3,int marks4,int marks5) {
	
	int sum = 0;
	int average;
	int percentage;
	
	sum = marks1 + marks2 + marks3 + marks4 + marks5;
	average = sum / 5;
	percentage = (sum / 5) * 100;
	cout <<"Sum is: " << sum;
	cout <<"Average is: " << average;
	cout << "Perentage is: " << percentage;

	return sum,average,percentage;
}

int main() {
	int marks[5];
	for (int i = 1; i <= 5; i++) {
		cout << "Enter marks of subject" << i << " : " << endl;
		cin >> marks[i];
	}
	data(marks[1], marks[2], marks[3], marks[4], marks[5]);

	return 0;
}