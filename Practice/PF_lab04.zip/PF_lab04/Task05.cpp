/*

// Display array through function:
#include<iostream>
using namespace std;
// Creating function:
void print_marks(int marks[5]) {
	for (int i = 1; i <= 5; i++) {
		cout << "Subject" << i << " marks: " << marks[i] << endl;
	}

}

int main() {
	int marks[5];
	// Taking input:
	for (int i = 1; i <= 5; i++) {
		cout << "Enter marks of subject " << i << " : " << endl;
		cin >> marks[i];
	}
	// Printing marks:
	print_marks(marks);
	return 0;
}*/
#include<iostream>
#include<fstream>
using namespace std;
int main() {
	int count = 0;
	char arr[100];
	
	ifstream read("STORY.TXT");
	while (!read.eof()) {
		read.getline(arr, 100, '\n');
		break;
		if (arr[0] == 'A') {
			count++;
		}
	}
	cout << "Lines starting with the alphabet 'A' are: " << count << endl;
	read.close();
	return 0;
}