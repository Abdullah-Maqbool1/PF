// Swapping values:
#include<iostream>
using namespace std;

int swap(int& a, int& b) {
	// Swappping:
	int temp = a;
	a = b;
	b = temp;
	return a, b;
}

int main()
{
	int a;
	int b;
	// Taking Input:
	cout << "Enter a: " << endl;
	cin >> a;
	cout << "Enter b: " << endl;
	cin >> b;
	// Printing:
	cout << "Before Swapping: \n";
	cout << "a is: " << a << endl;
	cout << "b is: " << b << endl;

	cout << "After Swapping: \n";
	swap(a, b);
	cout << "a is: " << a << endl;
	cout << "b is: " << b << endl;
	return 0;
}

// program will not swap if you dont give reference
// but will swap if you give reference.