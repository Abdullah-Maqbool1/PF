// Calculate square:
#include<iostream>
using namespace std;

int square(int a) {
	int sq = a * a;
	return sq;
}

int main() {
	int x;
	// Taking input:
	cout << "Enter a number: ";
	cin >> x;
	cout << endl;
	// Printing sqaure:
	cout << "The square of " << x << " is: " << square(x) << endl;
	
	return 0;
}