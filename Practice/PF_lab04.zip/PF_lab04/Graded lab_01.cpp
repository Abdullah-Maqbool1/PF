#include<iostream>
#include<fstream>
using namespace std;
int main() {
	int count = 0;
	char arr[100];
	fstream read;
	ifstream read("STORY.TXT");
	while (!read.eof()) {
		read.getline(arr, 100, '\n');
		break;
		if (arr[0] == 'A') {
			count++;
		}
	}
	cout << "Lines starting with the alphabet 'A' are: " << count << endl;
	read.close();
	return 0;
}