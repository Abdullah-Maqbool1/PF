
//Calculator
#include<iostream>
using namespace std;

int sum(int a, int b) {
    cout << a + b;
    return a + b;
}
int substract(int a, int b) {
    cout << a - b;
    return a - b;
}
int multiply(int a, int b) {
    cout << a * b;
    return a * b;
}
int divide(int a, int b) {
    cout << a / b;
    return a / b;
}
int calculator(int a, int b, char operation) {
    switch (operation) {
    case '+':
        return sum(a, b);
    case '-':
        return substract(a, b);
    case '*':
        return multiply(a, b);
    case '/':
        return divide(a, b);

    default:
        cout << "Invalid Operator!" << endl;
    }

}
int main() {
    int x, y;
    char operation;
    cout << "Enter First number: " << endl;
    cin >> x;
    cout << "Enter Secont number: " << endl;
    cin >> y;
    cout << "Which operation do you want to perform?\n a: '+' \n b: '-' \n c: '*' \n d: '/'" << endl;
    cin >> operation;
    calculator(x, y, operation);
    return 0;
}